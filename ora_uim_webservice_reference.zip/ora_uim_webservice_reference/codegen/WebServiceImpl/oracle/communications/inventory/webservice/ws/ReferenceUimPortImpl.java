package oracle.communications.inventory.webservice.ws;

import javax.jws.WebService;
import weblogic.jws.*;

/**
 * ReferenceUimPortImpl class implements web service endpoint interface ReferenceUimPort */

@WebService(
  serviceName="ReferenceUim",
  targetNamespace="http://xmlns.oracle.com/communications/inventory/webservice/reference",
  endpointInterface="oracle.communications.inventory.webservice.ws.ReferenceUimPort")
@WLHttpTransport(contextPath="ReferenceUim",serviceUri="ReferenceUimHTTP",portName="ReferenceUimHTTPPort")

public class ReferenceUimPortImpl implements ReferenceUimPort {
 
  public ReferenceUimPortImpl() {
  
  }

  public oracle.communications.inventory.webservice.findServiceByDeviceName.FindServiceByDeviceNameResponseType findServiceByDeviceName(oracle.communications.inventory.webservice.findServiceByDeviceName.FindServiceByDeviceNameRequestType parameters) 
    throws oracle.communications.inventory.webservice.framework.fault.InventoryFaultType, oracle.communications.inventory.webservice.framework.fault.ValidationFaultType 
  {
    // TODO replace with your impl here
     return null;     
  }
}  