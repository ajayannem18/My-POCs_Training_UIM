/**
 * Generated from schema type t=ConfigItemType@http://xmlns.oracle.com/communications/inventory/webservice/findServiceByDeviceName
 */
package oracle.communications.inventory.webservice.findServiceByDeviceName;

public class ConfigItemType implements java.io.Serializable {

  private java.lang.String itemName;

  public java.lang.String getItemName() {
    return this.itemName;
  }

  public void setItemName(java.lang.String itemName) {
    this.itemName = itemName;
  }

  private oracle.communications.inventory.webservice.findServiceByDeviceName.ResourceType[] resource;

  public oracle.communications.inventory.webservice.findServiceByDeviceName.ResourceType[] getResource() {
    return this.resource;
  }

  public void setResource(oracle.communications.inventory.webservice.findServiceByDeviceName.ResourceType[] resource) {
    this.resource = resource;
  }

  private oracle.communications.inventory.webservice.findServiceByDeviceName.ChildConfigItemType[] childConfigItem;

  public oracle.communications.inventory.webservice.findServiceByDeviceName.ChildConfigItemType[] getChildConfigItem() {
    return this.childConfigItem;
  }

  public void setChildConfigItem(oracle.communications.inventory.webservice.findServiceByDeviceName.ChildConfigItemType[] childConfigItem) {
    this.childConfigItem = childConfigItem;
  }

}
