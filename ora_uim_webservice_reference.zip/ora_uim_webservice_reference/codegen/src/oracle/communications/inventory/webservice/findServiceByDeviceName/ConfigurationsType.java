/**
 * Generated from schema type t=ConfigurationsType@http://xmlns.oracle.com/communications/inventory/webservice/findServiceByDeviceName
 */
package oracle.communications.inventory.webservice.findServiceByDeviceName;

public class ConfigurationsType implements java.io.Serializable {

  private java.lang.String configName;

  public java.lang.String getConfigName() {
    return this.configName;
  }

  public void setConfigName(java.lang.String configName) {
    this.configName = configName;
  }

  private java.lang.String configStatus;

  public java.lang.String getConfigStatus() {
    return this.configStatus;
  }

  public void setConfigStatus(java.lang.String configStatus) {
    this.configStatus = configStatus;
  }

  private oracle.communications.inventory.webservice.findServiceByDeviceName.ConfigItemType[] configItem;

  public oracle.communications.inventory.webservice.findServiceByDeviceName.ConfigItemType[] getConfigItem() {
    return this.configItem;
  }

  public void setConfigItem(oracle.communications.inventory.webservice.findServiceByDeviceName.ConfigItemType[] configItem) {
    this.configItem = configItem;
  }

}
