/**
 * Generated from schema type t=FindServiceByDeviceNameRequestType@http://xmlns.oracle.com/communications/inventory/webservice/findServiceByDeviceName
 */
package oracle.communications.inventory.webservice.findServiceByDeviceName;

public class FindServiceByDeviceNameRequestType implements java.io.Serializable {

  private java.lang.String deviceName;

  public java.lang.String getDeviceName() {
    return this.deviceName;
  }

  public void setDeviceName(java.lang.String deviceName) {
    this.deviceName = deviceName;
  }

}
