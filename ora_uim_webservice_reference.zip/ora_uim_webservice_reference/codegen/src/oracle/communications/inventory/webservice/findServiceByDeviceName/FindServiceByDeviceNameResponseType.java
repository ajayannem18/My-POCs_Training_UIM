/**
 * Generated from schema type t=FindServiceByDeviceNameResponseType@http://xmlns.oracle.com/communications/inventory/webservice/findServiceByDeviceName
 */
package oracle.communications.inventory.webservice.findServiceByDeviceName;

public class FindServiceByDeviceNameResponseType implements java.io.Serializable {

  private oracle.communications.inventory.webservice.findServiceByDeviceName.ServiceType[] service;

  public oracle.communications.inventory.webservice.findServiceByDeviceName.ServiceType[] getService() {
    return this.service;
  }

  public void setService(oracle.communications.inventory.webservice.findServiceByDeviceName.ServiceType[] service) {
    this.service = service;
  }

}
