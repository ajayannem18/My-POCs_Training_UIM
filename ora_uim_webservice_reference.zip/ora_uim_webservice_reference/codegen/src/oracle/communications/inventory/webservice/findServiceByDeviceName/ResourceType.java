/**
 * Generated from schema type t=ResourceType@http://xmlns.oracle.com/communications/inventory/webservice/findServiceByDeviceName
 */
package oracle.communications.inventory.webservice.findServiceByDeviceName;

public class ResourceType implements java.io.Serializable {

  private java.lang.String resourceName;

  public java.lang.String getResourceName() {
    return this.resourceName;
  }

  public void setResourceName(java.lang.String resourceName) {
    this.resourceName = resourceName;
  }

  private java.lang.String resourceId;

  public java.lang.String getResourceId() {
    return this.resourceId;
  }

  public void setResourceId(java.lang.String resourceId) {
    this.resourceId = resourceId;
  }

}
