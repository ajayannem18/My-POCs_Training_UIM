/**
 * Generated from schema type t=ServiceType@http://xmlns.oracle.com/communications/inventory/webservice/findServiceByDeviceName
 */
package oracle.communications.inventory.webservice.findServiceByDeviceName;

public class ServiceType implements java.io.Serializable {

  private java.lang.String serviceName;

  public java.lang.String getServiceName() {
    return this.serviceName;
  }

  public void setServiceName(java.lang.String serviceName) {
    this.serviceName = serviceName;
  }

  private java.lang.String serviceId;

  public java.lang.String getServiceId() {
    return this.serviceId;
  }

  public void setServiceId(java.lang.String serviceId) {
    this.serviceId = serviceId;
  }

  private java.lang.String serviceStatus;

  public java.lang.String getServiceStatus() {
    return this.serviceStatus;
  }

  public void setServiceStatus(java.lang.String serviceStatus) {
    this.serviceStatus = serviceStatus;
  }

  private oracle.communications.inventory.webservice.findServiceByDeviceName.CharacteristicType[] characteristic;

  public oracle.communications.inventory.webservice.findServiceByDeviceName.CharacteristicType[] getCharacteristic() {
    return this.characteristic;
  }

  public void setCharacteristic(oracle.communications.inventory.webservice.findServiceByDeviceName.CharacteristicType[] characteristic) {
    this.characteristic = characteristic;
  }

  private oracle.communications.inventory.webservice.findServiceByDeviceName.ConfigurationsType[] configurations;

  public oracle.communications.inventory.webservice.findServiceByDeviceName.ConfigurationsType[] getConfigurations() {
    return this.configurations;
  }

  public void setConfigurations(oracle.communications.inventory.webservice.findServiceByDeviceName.ConfigurationsType[] configurations) {
    this.configurations = configurations;
  }

}
