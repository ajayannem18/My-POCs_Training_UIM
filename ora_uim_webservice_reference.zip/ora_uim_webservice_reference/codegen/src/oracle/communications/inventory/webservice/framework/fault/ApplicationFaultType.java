/**
 * Generated from schema type t=ApplicationFaultType@http://xmlns.oracle.com/communications/framework/webservice/fault/v1-0
 */
package oracle.communications.inventory.webservice.framework.fault;

public class ApplicationFaultType implements java.io.Serializable {

  private java.lang.String errorCode;

  public java.lang.String getErrorCode() {
    return this.errorCode;
  }

  public void setErrorCode(java.lang.String errorCode) {
    this.errorCode = errorCode;
  }

  private java.lang.String errorMessage;

  public java.lang.String getErrorMessage() {
    return this.errorMessage;
  }

  public void setErrorMessage(java.lang.String errorMessage) {
    this.errorMessage = errorMessage;
  }

  private java.lang.String[] errorContext;

  public java.lang.String[] getErrorContext() {
    return this.errorContext;
  }

  public void setErrorContext(java.lang.String[] errorContext) {
    this.errorContext = errorContext;
  }

}
