/**
 * Generated from schema type t=InventoryFaultType@http://xmlns.oracle.com/communications/inventory/webservice/fault
 */
package oracle.communications.inventory.webservice.framework.fault;

public class InventoryFaultType extends java.lang.Exception {

  private oracle.communications.inventory.webservice.framework.fault.ApplicationFaultType fault;

  public oracle.communications.inventory.webservice.framework.fault.ApplicationFaultType getFault() {
    return this.fault;
  }

  public InventoryFaultType() {
  }

  public InventoryFaultType(oracle.communications.inventory.webservice.framework.fault.ApplicationFaultType fault) {
    this.fault = fault;
  }

}
