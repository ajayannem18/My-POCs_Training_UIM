/**
 * Generated from schema type t=ValidationFaultType@http://xmlns.oracle.com/communications/inventory/webservice/fault
 */
package oracle.communications.inventory.webservice.framework.fault;

public class ValidationFaultType extends oracle.communications.inventory.webservice.framework.fault.InventoryFaultType {

  public ValidationFaultType() {
  }

  public ValidationFaultType(oracle.communications.inventory.webservice.framework.fault.ApplicationFaultType fault) {
    super(fault);
  }

}
