package oracle.communications.inventory.webservice.adapter.common;

// API imports
import oracle.communications.inventory.api.framework.logging.Log;
import oracle.communications.inventory.api.framework.logging.LogFactory;

// ✅ NEW IMPORTS (IMPORTANT)
import oracle.communications.inventory.webservice.adapter.findServiceByDeviceName.FindServiceByDeviceNameAdapter;
import oracle.communications.inventory.webservice.findServiceByDeviceName.FindServiceByDeviceNameRequestType;
import oracle.communications.inventory.webservice.findServiceByDeviceName.FindServiceByDeviceNameResponseType;

// Faults
import oracle.communications.inventory.webservice.framework.fault.InventoryFaultType;
import oracle.communications.inventory.webservice.framework.fault.ValidationFaultType;

/**
 * Adapter Router Class
 */
public class AdapterRouter {

    private static final Log log = LogFactory.getLog(AdapterRouter.class);

    /**
     * Existing method - Create Logical Device
     */
//    public CreateLogicalDeviceResponseType createLogicalDevice(
//            CreateLogicalDeviceRequestType createLogicalDeviceRequest)
//            throws InventoryFaultType, ValidationFaultType {
//
//        log.debug("", "In AdapterRouter.createLogicalDevice");
//
//        return new LogicalDeviceAdapter()
//                .createLogicalDevice(createLogicalDeviceRequest);
//    }

    // ============================================================
    // ✅ NEW METHOD (YOUR CUSTOM SERVICE)
    // ============================================================

    public FindServiceByDeviceNameResponseType findServiceByDeviceName(
            FindServiceByDeviceNameRequestType request)
            throws InventoryFaultType, ValidationFaultType {

        log.debug("", "In AdapterRouter.findServiceByDeviceName");

        return new FindServiceByDeviceNameAdapter()
                .findServiceByDeviceName(request);
    }
}