/*
* Copyright (c) 2011, 2013, Oracle and/or its affiliates. All rights reserved. 
 * Oracle Corporation and/or its affiliates. Other names may be trademarks of their respective owners. 
 *
 * This sample file, which has been provided by Oracle Corporation as part of an Oracle(r) product for usee
 * ONLY by licensed users of the product, includes CONFIDENTIAL and PROPRIETARY information of Oracle
 * Corporation.
 *
 * This material is the confidential property of Oracle Corporation or its licensors and may be used,
 * reproduced, stored, or transmitted only in accordance with a valid Oracle license or sublicense
 * agreement.
 *
 * USE OF THIS SOFTWARE IS GOVERNED BY THE TERMS AND CONDITIONS OF THE LICENSE
 * AGREEMENT AND LIMITED WARRANTY FURNISHED WITH THE PRODUCT.
 *
 * IN PARTICULAR, YOU WILL INDEMNIFY AND HOLD ORACLE CORPORATION, ITS RELATED COMPANIES AND ITS SUPPLIERS,
 * HARMLESS FROM AND AGAINST ANY CLAIMS OR LIABILITIES ARISING OUT OF THE USE, REPRODUCTION, OR DISTRIBUTION
 * OF YOUR PROGRAMS, INCLUDING ANY CLAIMS OR LIABILITIES ARISING OUT OF OR RESULTING FROM THE USE,
 * MODIFICATION, OR DISTRIBUTION OF PROGRAMS OR FILES CREATED FROM, BASED ON, AND/OR DERIVED FROM THIS
 * SAMPLE SOURCE CODE FILE.
 */
package oracle.communications.inventory.webservice.adapter.common;

// Java imports
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.communications.inventory.api.exception.InventoryException;
import oracle.communications.inventory.api.exception.ValidationException;
import oracle.communications.inventory.api.framework.logging.FeedbackMessage;
import oracle.communications.inventory.api.framework.logging.FeedbackProvider;
import oracle.communications.inventory.api.framework.logging.Log;
import oracle.communications.inventory.api.framework.logging.LogFactory;
import oracle.communications.inventory.api.framework.logging.impl.FeedbackProviderImpl;
import oracle.communications.inventory.api.util.Utils;
import oracle.communications.inventory.webservice.framework.InventoryAdapterRoot;
import oracle.communications.inventory.webservice.framework.fault.ApplicationFaultType;
import oracle.communications.inventory.webservice.framework.fault.InventoryFaultType;
import oracle.communications.inventory.webservice.framework.fault.ValidationFaultType;

 
/**
 * This class provides methods that map exceptions to Faults.
 * The FaultMap hashstable contains a key value mapping of exceptions to Faults.
 * All new Faults should be ampped to exceptions here.
 * 
 * The assumption is that all exceptions thrown from the Java API are 
 * extended from IventoryException. The only ones that are not are
 * the runtime exceptions.
 * 
 */
public class FaultFactory
{
    private static Map<String, Class<?>> faultMap = new HashMap<String, Class<?>>();
    private static  final Class<?> ARG_TYPES[] = new Class<?>[] { String[].class, String.class };
    private static final Log log = LogFactory.getLog( InventoryAdapterRoot.class );

	/**
	 * Static hashmap that stores the key/value pair for mapping Exception to FaultType.
	 * The key should be a child of InventoryException.
	 * 
	 */
	static
	{
		faultMap.put(InventoryException.class.getName(), InventoryFaultType.class);
		faultMap.put(ValidationException.class.getName(), ValidationFaultType.class);		
	}

    public static InventoryFaultType getFaultType( final Throwable throwable )
    {
        InventoryFaultType fault = new InventoryFaultType();
        if( throwable instanceof InventoryException )
        {
            fault = getInventoryFaultType( (InventoryException) throwable );
        }
        else
        {
            log.error( "", throwable );
            fault = getInventoryFaultType( throwable );
        }
        return fault;
    }
    
    @SuppressWarnings("unchecked")
    public static InventoryFaultType getInventoryFaultType(
        InventoryException inventoryException )
    {
    	final ApplicationFaultType[] errorMessages = getErrorMessages( inventoryException );
        InventoryFaultType fault = null;
        try
        {
        	Class<?> c = (Class<?>) faultMap.get( inventoryException.getClass().getName() );
        	if( c != null ) {
	        	if ( !Utils.isEmpty( errorMessages ) ) {
	        		for ( ApplicationFaultType errorMessage : errorMessages  ) {
	        			if ( Utils.checkBlank( errorMessage.getErrorMessage() ) ) {
	        				continue;
	        			}
	        			else {
	        				
	        				Constructor constructor = c.getConstructor( ApplicationFaultType.class );
	        				fault = (InventoryFaultType) constructor.newInstance( errorMessage );
	        				break;
	        			}
	        		}
	        	}
        	}
        }
        catch( Exception e )
        {
            // ignore
        }
        if( fault == null )
        {
        	ApplicationFaultType errorMessage = null;
        	if ( !Utils.isEmpty( errorMessages ) ) {
        		//at less, get one errorMessage
        		errorMessage = errorMessages[0];
        		for ( ApplicationFaultType errorMsg : errorMessages  ) {
        			if ( Utils.checkBlank( errorMsg.getErrorMessage() ) ) {
        				continue;
        			}
        			else {
        				errorMessage = errorMsg;
        			}
        		}
        	}
        		
            fault = new InventoryFaultType( errorMessage );
        }
        return fault;
    }


    private static ApplicationFaultType[] getErrorMessages( InventoryException inventoryException )
        {
            if( inventoryException.getMessages() == null
                || inventoryException.getMessages().size() <= 0 ){
                return getFeedbackMessages();
            }
            ApplicationFaultType[] faults = new ApplicationFaultType[inventoryException.getMessages().size()];
            int i = 0;
            for( FeedbackMessage feedbackMessage : inventoryException.getMessages() )
            {
            	ApplicationFaultType fault = new ApplicationFaultType(); 
            	fault.setErrorCode( feedbackMessage.getId() );
            	fault.setErrorMessage( feedbackMessage.getMessage() );
            	faults[i++] = fault;
            }
            return faults;
        }
    
    
    private static ApplicationFaultType[] getFeedbackMessages()
    {
        FeedbackProvider feedback = FeedbackProviderImpl.getFeedbackProvider();
        List<FeedbackMessage> msgs = feedback.getMessages();
        ApplicationFaultType[] faults = new ApplicationFaultType[ msgs.size() ];
        int i = 0;
        for( FeedbackMessage m : msgs )
        {
            StringBuffer buffer = new StringBuffer( m.getMessage() );
            if( m.getThrowable() != null )
            {
                Throwable t = m.getThrowable();
                buffer.append( " with exception: "  );
                buffer.append( t.getClass().getName() );
                buffer.append( ": " );
                if( t.getLocalizedMessage() != null )
                {
                    buffer.append( ": " );
                    buffer.append( t.getLocalizedMessage() );
                }
            }
            ApplicationFaultType fault = new ApplicationFaultType(); 
        	fault.setErrorCode( "" );
        	fault.setErrorMessage( buffer.toString() );
            faults[i++] = fault;
        }
        return faults;
    }
    
    public static InventoryFaultType getInventoryFaultType( Throwable throwable )
    {
        if( throwable instanceof InventoryFaultType ){
        	return (InventoryFaultType) throwable;
        }
            
        ApplicationFaultType f = new ApplicationFaultType();
        f.setErrorCode("");
        f.setErrorMessage( throwable.getMessage() );
        log.error( "", throwable );
        InventoryFaultType fault = new InventoryFaultType( f );
        return fault;
    }
}
