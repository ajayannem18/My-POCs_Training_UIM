/*
* Copyright (c) 2011, 2013, Oracle and/or its affiliates. All rights reserved. 
 * Oracle Corporation and/or its affiliates. Other names may be trademarks of their respective owners. 
 *
 * This sample file, which has been provided by Oracle Corporation as part of an Oracle(r) product for usee
 * ONLY by licensed users of the product, includes CONFIDENTIAL and PROPRIETARY information of Oracle
 * Corporation.
 *
 * This material is the confidential property of Oracle Corporation or its licensors and may be used,
 * reproduced, stored, or transmitted only in accordance with a valid Oracle license or sublicense
 * agreement.
 *
 * USE OF THIS SOFTWARE IS GOVERNED BY THE TERMS AND CONDITIONS OF THE LICENSE
 * AGREEMENT AND LIMITED WARRANTY FURNISHED WITH THE PRODUCT.
 *
 * IN PARTICULAR, YOU WILL INDEMNIFY AND HOLD ORACLE CORPORATION, ITS RELATED COMPANIES AND ITS SUPPLIERS,
 * HARMLESS FROM AND AGAINST ANY CLAIMS OR LIABILITIES ARISING OUT OF THE USE, REPRODUCTION, OR DISTRIBUTION
 * OF YOUR PROGRAMS, INCLUDING ANY CLAIMS OR LIABILITIES ARISING OUT OF OR RESULTING FROM THE USE,
 * MODIFICATION, OR DISTRIBUTION OF PROGRAMS OR FILES CREATED FROM, BASED ON, AND/OR DERIVED FROM THIS
 * SAMPLE SOURCE CODE FILE.
 */
package oracle.communications.inventory.webservice.adapter.common;

import java.util.ArrayList;
import java.util.List;

import oracle.communications.inventory.api.framework.logging.FeedbackMessage;
import oracle.communications.inventory.api.framework.logging.FeedbackProvider;
import oracle.communications.inventory.api.framework.logging.FeedbackProvider.FeedbackLevel;
import oracle.communications.inventory.webservice.framework.common.InventoryResponseType;
import oracle.communications.inventory.webservice.framework.fault.ApplicationFaultType;
import oracle.communications.inventory.api.framework.logging.impl.FeedbackProviderImpl;
import oracle.communications.inventory.api.util.Utils;

public class FeedbackUtils
{
    private static final String SUCCESS = "Success";
    private static String[] translateFeedback( List<FeedbackMessage> msgs )
    {
        String[] result = new String[msgs.size()];
        int i = 0;
        for( FeedbackMessage m : msgs )
        {
            StringBuffer buffer = new StringBuffer( m.getMessage() );
            if( m.getThrowable() != null )
            {
                Throwable t = m.getThrowable();
                buffer.append( " with exception: " );
                buffer.append( t.getClass().getName() );
                if( t.getLocalizedMessage() != null )
                {
                    buffer.append( ": " );
                    buffer.append( t.getLocalizedMessage() );
                }
            }
            result[i] = buffer.toString();
            i++;
        }
        return result;
    }
    private static ApplicationFaultType[] translateFeedbackError( List<FeedbackMessage> feedbackMessages )
    {
    	
    	ApplicationFaultType[] faults = new ApplicationFaultType[feedbackMessages.size()];

        int i = 0;

        for (FeedbackMessage feedbackMessage : feedbackMessages ) {
                ApplicationFaultType fault = new ApplicationFaultType();
                fault.setErrorCode( feedbackMessage.getId() );
                fault.setErrorMessage( feedbackMessage.getMessage() );
                faults[i++] = fault;
        }

        return faults;
    }

    public static void copyFeedbacktoResponse( InventoryResponseType response )
    {
        List<String> messages = new ArrayList<String>();
        if( !FeedbackProviderImpl.hasErrors() )
            messages.add( SUCCESS );
        FeedbackProvider feedback = FeedbackProviderImpl.getFeedbackProvider();
        response.setErrors( translateFeedbackError( feedback.getErrors() ) );
        response.setWarnings( translateFeedback( feedback.getWarnings() ) );
        for( String m : translateFeedback( feedback.getNotes() ) )
            messages.add( m );
        for( String m : translateFeedback( feedback.getTraces() ) )
            messages.add( m );
        for( String m : translateFeedback( feedback.getDebugs() ) )
            messages.add( m );
        response.setMessages( (String[]) messages.toArray( new String[messages
            .size()] ) );
    }

    public static String[] getFeedbackErrors()
    {
        FeedbackProvider feedback = FeedbackProviderImpl.getFeedbackProvider();
        return translateFeedback( feedback.getErrors() );
    }
    
    public static ApplicationFaultType[] getFeedbackFaults()
    {
        FeedbackProvider feedback = FeedbackProviderImpl.getFeedbackProvider();

        List<FeedbackMessage> feedbackMessages = feedback.getErrors();

        ApplicationFaultType[] faults = new ApplicationFaultType[feedbackMessages.size()];

        int i = 0;

        for (FeedbackMessage feedbackMessage : feedbackMessages ) {
                ApplicationFaultType fault = new ApplicationFaultType();
                fault.setErrorCode( feedbackMessage.getId() );
                fault.setErrorMessage( feedbackMessage.getMessage() );
                faults[i++] = fault;
        }

        return faults;
    }
    
    public static ApplicationFaultType getFeedbackFault()
    {
        FeedbackProvider feedback = FeedbackProviderImpl.getFeedbackProvider();

        List<FeedbackMessage> feedbackMessages = feedback.getErrors();

        ApplicationFaultType fault = null;
        
        if( !Utils.isEmpty( feedbackMessages ) ) {
        	FeedbackMessage fm = feedbackMessages.iterator().next();
        	fault = new ApplicationFaultType();
        	fault.setErrorCode( fm.getId() );
        	fault.setErrorMessage( fm.getMessage() );
        }

        return fault;
    }
    
    
    public static boolean hasErrors()
    {
        FeedbackProvider feedback = FeedbackProviderImpl.getFeedbackProvider();
        return feedback.hasMessages(FeedbackLevel.ERROR);
    }
}
