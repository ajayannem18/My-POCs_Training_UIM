package oracle.communications.inventory.webservice.adapter.findServiceByDeviceName;

import java.util.ArrayList;
import java.util.List;

import oracle.communications.inventory.api.entity.LogicalDevice;
import oracle.communications.inventory.api.entity.Service;
import oracle.communications.inventory.api.entity.ServiceConfigurationItem;
import oracle.communications.inventory.api.entity.ServiceConfigurationVersion;
import oracle.communications.inventory.api.entity.common.Consumer;
import oracle.communications.inventory.api.framework.security.UserEnvironment;

import oracle.communications.inventory.api.logicaldevice.LogicalDeviceManager;
import oracle.communications.inventory.api.logicaldevice.LogicalDeviceSearchCriteria;

import oracle.communications.inventory.webservice.findServiceByDeviceName.FindServiceByDeviceNameRequestType;
import oracle.communications.inventory.webservice.findServiceByDeviceName.FindServiceByDeviceNameResponseType;
import oracle.communications.inventory.webservice.findServiceByDeviceName.ServiceType;

import oracle.communications.inventory.webservice.adapter.common.FaultFactory;
import oracle.communications.inventory.webservice.framework.InventoryAdapterRoot;
import oracle.communications.inventory.webservice.framework.InventoryTransactionValue;
import oracle.communications.inventory.webservice.framework.fault.InventoryFaultType;
import oracle.communications.inventory.webservice.framework.fault.ValidationFaultType;

import oracle.communications.inventory.webservice.mapper.FindServiceMapper;

import oracle.communications.platform.persistence.CriteriaItem;
import oracle.communications.platform.persistence.CriteriaOperator;
import oracle.communications.platform.persistence.PersistenceHelper;
import oracle.communications.platform.persistence.Persistent;

public class FindServiceByDeviceNameAdapter extends InventoryAdapterRoot {

    public FindServiceByDeviceNameResponseType findServiceByDeviceName(
            FindServiceByDeviceNameRequestType request)
            throws InventoryFaultType, ValidationFaultType {

        System.out.println("Start findServiceByDeviceName");

        FindServiceByDeviceNameResponseType response =
                new FindServiceByDeviceNameResponseType();

        UserEnvironment userEnvironment = null;
        InventoryTransactionValue transValue = null;

        try {

            System.out.println("Step 1 start environment");

            userEnvironment = startUserEnvironment();
            transValue = startTransaction();
            transValue.setUserEnvironment(userEnvironment);

            System.out.println("Step 2 validate request");

            if (request == null || request.getDeviceName() == null ||
                request.getDeviceName().trim().isEmpty()) {

                System.out.println("Invalid request");

                ValidationFaultType fault = new ValidationFaultType();
                System.out.println("Device name is mandatory");
                throw fault;
            }

            String deviceName = request.getDeviceName();
            System.out.println("Device name " + deviceName);

            System.out.println("Step 3 find logical device");

            LogicalDeviceManager ldMgr = PersistenceHelper.makeLogicalDeviceManager();
            LogicalDeviceSearchCriteria criteria = ldMgr.makeLogicalDeviceSearchCriteria();

            CriteriaItem nameItem = criteria.makeCriteriaItem();
            nameItem.setValue(deviceName);
            nameItem.setOperator(CriteriaOperator.EQUALS);
            criteria.setName(nameItem);

            List<LogicalDevice> devices = ldMgr.findLogicalDevice(criteria);

            if (devices == null || devices.isEmpty()) {

                System.out.println("No logical device found");

                ValidationFaultType fault = new ValidationFaultType();
                System.out.println("Logical device not found");
                throw fault;
            }

            LogicalDevice ld = devices.get(0);
            System.out.println("Logical device found " + ld.getName());

            System.out.println("Step 4 get associated services");

            List<ServiceType> serviceList = new ArrayList<>();

            // ===== MULTI SERVICE HANDLING =====
            if (ld.getCurrentAssignment() != null &&
                ld.getCurrentAssignment().getConsumer() != null) {

                Persistent result = ld.getCurrentAssignment().getConsumer();

                if (result instanceof Service) {

                    Service uimService = (Service) result;

                    System.out.println("Service found " + uimService.getName());

                    // ===== FORCE LOAD GRAPH =====
                    System.out.println("Loading full service graph");

                    if (uimService.getConfigurations() != null) {

                        uimService.getConfigurations().size(); // force load

                        for (ServiceConfigurationVersion scv : uimService.getConfigurations()) {

                            System.out.println("Loading configuration " + scv.getName());

                            if (scv.getConfigItems() != null) {

                                scv.getConfigItems().size();

                                for (ServiceConfigurationItem item : scv.getConfigItems()) {

                                    if (item == null) continue;

                                    if (item.getAssignment() != null) {
                                        ((Consumer) item.getAssignment()).getResource();
                                    }

                                    if (item.getChildConfigItems() != null) {

                                        item.getChildConfigItems().size();

                                        for (ServiceConfigurationItem child : item.getChildConfigItems()) {

                                            if (child == null) continue;

                                            if (child.getAssignment() != null) {
                                                ((Consumer) child.getAssignment()).getResource();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ===== MAP SERVICE =====
                    ServiceType wsService = new ServiceType();
                    FindServiceMapper.mapService(uimService, wsService);

                    serviceList.add(wsService);
                }
            }

            // ===== SET RESPONSE =====
            if (!serviceList.isEmpty()) {

                response.setService(
                        serviceList.toArray(new ServiceType[serviceList.size()])
                );

                System.out.println("Total services returned " + serviceList.size());
            } else {

                System.out.println("No services associated");

                ValidationFaultType fault = new ValidationFaultType();
                System.out.println("No service associated with device");
                throw fault;
            }

            System.out.println("Step 6 commit transaction");

            if (transValue != null) {
                commitOrRollback(transValue);
            }

            System.out.println("Transaction committed");

        } catch (Throwable t) {

            System.out.println("Error occurred");
            t.printStackTrace();

            try {
                rollback(transValue);
            } catch (Exception ignore) {
                System.out.println("Rollback failed");
            }

            throw FaultFactory.getFaultType(t);

        } finally {

            System.out.println("Finally block");

            if (userEnvironment != null) {
                System.out.println("User environment errors " + userEnvironment.hasErrors());
            }

            endUserEnvironment(userEnvironment, null);
        }

        System.out.println("End findServiceByDeviceName");

        return response;
    }
}