package oracle.communications.inventory.webservice.mapper;

import java.util.ArrayList;
import java.util.List;

import oracle.communications.inventory.api.entity.ServiceCharacteristic;
import oracle.communications.inventory.api.entity.ServiceConfigurationItem;
import oracle.communications.inventory.api.entity.ServiceConfigurationVersion;
import oracle.communications.inventory.api.entity.common.Assignment;

import oracle.communications.inventory.webservice.findServiceByDeviceName.*;

public class FindServiceMapper {

    public static void mapService(
            oracle.communications.inventory.api.entity.Service uimService,
            ServiceType wsService) {

        System.out.println("Mapping service");

        // ===== BASIC =====
        wsService.setServiceName(uimService.getName());

        if (uimService.getId() != null) {
            wsService.setServiceId(String.valueOf(uimService.getId()));
        }

        if (uimService.getAdminState() != null) {
            wsService.setServiceStatus(uimService.getAdminState().toString());
        }

        // ===== CHARACTERISTICS =====
        if (uimService.getCharacteristics() != null) {

            List<CharacteristicType> charList = new ArrayList<>();

            for (ServiceCharacteristic ch : uimService.getCharacteristics()) {

                if (ch == null || ch.getName() == null) continue;

                System.out.println("Mapping characteristic " + ch.getName());

                CharacteristicType c = new CharacteristicType();
                c.setName(ch.getName());

                if (ch.getValue() != null) {
                    c.setValue(ch.getValue().toString());
                }

                charList.add(c);
            }

            if (!charList.isEmpty()) {
                wsService.setCharacteristic(
                        charList.toArray(new CharacteristicType[charList.size()])
                );
            }
        }

        // ===== CONFIGURATIONS =====
        List<ConfigurationsType> configList = new ArrayList<>();

        if (uimService.getConfigurations() != null) {

            for (ServiceConfigurationVersion scv : uimService.getConfigurations()) {

                System.out.println("Mapping configuration " + scv.getName());

                ConfigurationsType config = new ConfigurationsType();
                config.setConfigName(scv.getName());

                if (scv.getAdminState() != null) {
                    config.setConfigStatus(scv.getAdminState().toString());
                }

                List<ConfigItemType> itemList = new ArrayList<>();

                if (scv.getConfigItems() != null) {

                    boolean rootHandled = false;

                    for (ServiceConfigurationItem item : scv.getConfigItems()) {

                        if (item == null) continue;

                        // ===== HANDLE ROOT WRAPPER =====
                        if (item.getName() == null && !rootHandled) {

                            rootHandled = true;

                            System.out.println("Handling root wrapper item");

                            if (item.getChildConfigItems() != null) {

                                for (ServiceConfigurationItem rootChild : item.getChildConfigItems()) {

                                    if (rootChild == null || rootChild.getName() == null) continue;

                                    System.out.println("Mapping root item " + rootChild.getName());

                                    ConfigItemType ci = new ConfigItemType();
                                    ci.setItemName(rootChild.getName());

                                    // ===== CHILD ITEMS =====
                                    List<ChildConfigItemType> childList = new ArrayList<>();

                                    if (rootChild.getChildConfigItems() != null) {

                                        for (ServiceConfigurationItem child : rootChild.getChildConfigItems()) {

                                            if (child == null || child.getName() == null) continue;

                                            System.out.println("Mapping child item " + child.getName());

                                            ChildConfigItemType childCi = new ChildConfigItemType();
                                            childCi.setItemName(child.getName());

                                            List<ResourceType> resList = new ArrayList<>();

                                            if (child.getAssignment() != null) {

                                                Assignment a = (Assignment) child.getAssignment();

                                                if (a.getResource() != null) {

                                                    ResourceType res = new ResourceType();
                                                    res.setResourceName(a.getResource().getName());

                                                    if (a.getResource().getId() != null) {
                                                        res.setResourceId(
                                                                String.valueOf(a.getResource().getId()));
                                                    }

                                                    resList.add(res);

                                                    System.out.println("Mapping resource " + res.getResourceName());
                                                }
                                            }

                                            if (!resList.isEmpty()) {
                                                childCi.setResource(
                                                        resList.toArray(new ResourceType[resList.size()])
                                                );
                                            }

                                            childList.add(childCi);
                                        }
                                    }

                                    if (!childList.isEmpty()) {
                                        ci.setChildConfigItem(
                                                childList.toArray(new ChildConfigItemType[childList.size()])
                                        );
                                    }

                                    itemList.add(ci);
                                }
                            }

                            continue;
                        }

                        // ===== SKIP DUPLICATES IF ROOT ALREADY HANDLED =====
                        if (rootHandled) {
                            continue;
                        }

                        // ===== FALLBACK (NO ROOT CASE) =====
                        if (item.getName() != null) {

                            System.out.println("Mapping fallback item " + item.getName());

                            ConfigItemType ci = new ConfigItemType();
                            ci.setItemName(item.getName());

                            itemList.add(ci);
                        }
                    }
                }

                if (!itemList.isEmpty()) {
                    config.setConfigItem(
                            itemList.toArray(new ConfigItemType[itemList.size()])
                    );
                }

                configList.add(config);
            }
        }

        if (!configList.isEmpty()) {
            wsService.setConfigurations(
                    configList.toArray(new ConfigurationsType[configList.size()])
            );
        }
    }
}