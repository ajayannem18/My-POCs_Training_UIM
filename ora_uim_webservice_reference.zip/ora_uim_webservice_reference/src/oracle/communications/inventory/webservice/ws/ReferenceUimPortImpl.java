/*
    * Copyright (c) 2011, 2013, Oracle and/or its affiliates. All rights reserved.
     * Oracle Corporation and/or its affiliates. Other names may be trademarks of their respective owners.
     *
     * This sample file, which has been provided by Oracle Corporation as part of an Oracle(r) product for usee
     * ONLY by licensed users of the product, includes CONFIDENTIAL and PROPRIETARY information of Oracle
     * Corporation.
     *
     * This material is the confidential property of Oracle Corporation or its licensors and may be used,
     * reproduced, stored, or transmitted only in accordance with a valid Oracle license or sublicense
     * agreement.
     *
     * USE OF THIS SOFTWARE IS GOVERNED BY THE TERMS AND CONDITIONS OF THE LICENSE
     * AGREEMENT AND LIMITED WARRANTY FURNISHED WITH THE PRODUCT.
     *
     * IN PARTICULAR, YOU WILL INDEMNIFY AND HOLD ORACLE CORPORATION, ITS RELATED COMPANIES AND ITS SUPPLIERS,
     * HARMLESS FROM AND AGAINST ANY CLAIMS OR LIABILITIES ARISING OUT OF THE USE, REPRODUCTION, OR DISTRIBUTION
     * OF YOUR PROGRAMS, INCLUDING ANY CLAIMS OR LIABILITIES ARISING OUT OF OR RESULTING FROM THE USE,
     * MODIFICATION, OR DISTRIBUTION OF PROGRAMS OR FILES CREATED FROM, BASED ON, AND/OR DERIVED FROM THIS
     * SAMPLE SOURCE CODE FILE.
     */
package oracle.communications.inventory.webservice.ws;
import oracle.communications.inventory.api.framework.logging.Log;
import oracle.communications.inventory.api.framework.logging.LogFactory;

import javax.jws.WebService;

import oracle.communications.inventory.webservice.adapter.common.AdapterRouter;
import oracle.communications.inventory.webservice.adapter.findServiceByDeviceName.FindServiceByDeviceNameAdapter;
import oracle.communications.inventory.webservice.findServiceByDeviceName.FindServiceByDeviceNameRequestType;
import oracle.communications.inventory.webservice.findServiceByDeviceName.FindServiceByDeviceNameResponseType;
import oracle.communications.inventory.webservice.framework.fault.InventoryFaultType;
import oracle.communications.inventory.webservice.framework.fault.ValidationFaultType;

/**
 * ReferenceUimPortImpl class implements web service endpoint interface ReferenceUimPort
 */

@WebService(serviceName = "ReferenceUim",
            targetNamespace = "http://xmlns.oracle.com/communications/inventory/webservice/reference",
            endpointInterface = "oracle.communications.inventory.webservice.ws.ReferenceUimPort")
public class ReferenceUimPortImpl implements ReferenceUimPort {
	private static final Log log = LogFactory.getLog(AdapterRouter.class);
    /**
     * constructor
     */
    public ReferenceUimPortImpl() {

    }

	@Override
	public FindServiceByDeviceNameResponseType findServiceByDeviceName(FindServiceByDeviceNameRequestType parameters)
			throws InventoryFaultType, ValidationFaultType {
		log.debug("", "In AdapterRouter.findServiceByDeviceName");

        return new FindServiceByDeviceNameAdapter()
                .findServiceByDeviceName(parameters);
	}

//    public CreateLogicalDeviceResponseType createLogicalDevice(CreateLogicalDeviceRequestType createLogicalDeviceRequest) throws ValidationFaultType,
//                                                                                                                                 InventoryFaultType {
//		return new AdapterRouter().createLogicalDevice(createLogicalDeviceRequest);
//        
//    }
}
